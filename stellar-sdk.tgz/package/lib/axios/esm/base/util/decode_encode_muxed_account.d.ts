import { MuxedAccount } from "../../xdr/index.js";
/**
 * Converts a Stellar address (in G... or M... form) to an `xdr.MuxedAccount`
 * structure, using the ed25519 representation when possible.
 *
 * This supports full muxed accounts, where an `M...` address will resolve to
 * both its underlying `G...` address and an integer ID.
 *
 * @param address - G... or M... address to encode into XDR
 */
export declare function decodeAddressToMuxedAccount(address: string): MuxedAccount;
/**
 * Converts an xdr.MuxedAccount to its StrKey representation.
 *
 * Returns the "M..." string representation if there is a muxing ID within
 * the object, or the "G..." representation otherwise.
 *
 * @param muxedAccount - raw account to stringify
 *
 * @see https://stellar.org/protocol/sep-23
 */
export declare function encodeMuxedAccountToAddress(muxedAccount: MuxedAccount): string;
/**
 * Transform a Stellar address (G...) and an ID into its XDR representation.
 *
 * @param address - a Stellar G... address
 * @param id - a Uint64 ID represented as a string
 */
export declare function encodeMuxedAccount(address: string, id: string): MuxedAccount;
/**
 * Extracts the underlying base (G...) address from an M-address.
 * @param address - an account address (either M... or G...)
 */
export declare function extractBaseAddress(address: string): string;
