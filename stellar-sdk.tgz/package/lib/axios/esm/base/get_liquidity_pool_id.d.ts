import { Asset } from "./asset.js";
export declare namespace LiquidityPoolType {
    type constantProduct = "constant_product";
}
export type LiquidityPoolType = LiquidityPoolType.constantProduct;
export declare namespace LiquidityPoolParameters {
    interface ConstantProduct {
        assetA: Asset;
        assetB: Asset;
        fee: number;
    }
}
export type LiquidityPoolParameters = LiquidityPoolParameters.ConstantProduct;
export declare const LiquidityPoolFeeV18 = 30;
/**
 * Computes the Pool ID for the given assets, fee and pool type.
 *
 * Returns the raw Pool ID bytes, which can be stringified with
 * `uint8ArrayToHex` from `uint8array-extras`.
 *
 * @see [stellar-core getPoolID](https://github.com/stellar/stellar-core/blob/9f3a48c6a8f1aa77b6043a055d0638661f718080/src/ledger/test/LedgerTxnTests.cpp#L3746-L3751)
 *
 * @param liquidityPoolType - A string representing the liquidity pool type.
 * @param liquidityPoolParameters - The liquidity pool parameters.
 *   - `assetA`: The first asset in the Pool, it must respect the rule `assetA < assetB`.
 *   - `assetB`: The second asset in the Pool, it must respect the rule `assetA < assetB`.
 *   - `fee`: The liquidity pool fee. For now the only fee supported is `30`.
 */
export declare function getLiquidityPoolId(liquidityPoolType: LiquidityPoolType, liquidityPoolParameters: LiquidityPoolParameters): Uint8Array<ArrayBufferLike>;
